<html style="width:100%;height:100%;background-color:black;"><head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="description" content="Play minecraft 1.8 in your browser">
		<meta name="keywords" content="eaglercraft, eaglercraftx, minecraft, 1.8, 1.8.8">
		<title>EaglyMC 1.20 WASM-GC</title>
		<meta property="og:locale" content="en-US">
		<meta property="og:type" content="website">
		<meta property="og:title" content="EaglyMC 1.20 WASM-GC">
		<meta property="og:description" content="Play minecraft 1.20(kinda) in your browser!">
			<script>
      var urlObj = new window.URL(window.location.href);
      var url = "https://eaglercraft.com/mc/a1.2.6/";
      if (url) {
        var win; document.querySelector('button').onclick = function() {
          if (win) {
            win.focus();
          } else {
            win = window.open();
            win.document.body.style.margin = '0';
            win.document.body.style.height = '100vh';
            var iframe = win.document.createElement('iframe');
            iframe.style.border = 'none';
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.margin = '0';
            iframe.src = url;
            win.document.body.appendChild(iframe);
          }
          document.querySelector('button').style.bacground = 'grey';
          document.querySelector('button').innerHTML = "Play Now";
          window.close()
        }
      }
   </script>
  </body>
 
</html>
